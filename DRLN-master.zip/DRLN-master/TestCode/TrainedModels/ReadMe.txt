Download the TrainedModels from here and replace this folder. All the models (BIX2/3/4/8, BDX3) can be downloaded from Google Drive (https://drive.google.com/open?id=1MwRNAcUOBcS0w6Q7gGNZWYO_AP_svi7i) or (https://icedrive.net/0/a81sqSW91R). The total size for all models is 737 MB.

