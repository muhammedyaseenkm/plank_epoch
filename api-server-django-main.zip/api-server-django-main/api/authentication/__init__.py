default_app_config = "api.authentication.apps.AuthenticationConfig"
