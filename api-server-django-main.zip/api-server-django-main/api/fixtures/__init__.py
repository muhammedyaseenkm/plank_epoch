def run_fixtures():
    import api.fixtures.user
